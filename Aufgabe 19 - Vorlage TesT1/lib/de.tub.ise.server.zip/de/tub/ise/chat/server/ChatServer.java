package de.tub.ise.chat.server;

import de.tub.ise.chat.ChatMessage;
import de.tub.ise.chat.util.Logger;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.LinkedList;
import java.util.concurrent.ConcurrentSkipListSet;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.PriorityBlockingQueue;

public  class ChatServer implements Runnable {

    public static boolean verbose = false;

	ExecutorService threadPool = Executors.newFixedThreadPool(64*2);

    Thread serverThread;
    Thread watchdogThread;

    //Connection
    ServerSocket socket;

    final PriorityBlockingQueue<ChatSession> sessions = new PriorityBlockingQueue<>();

    @SuppressWarnings("serial")
	ObservableSet<ChatMessage> messages = new ObservableSetWrapper<ChatMessage>(new ConcurrentSkipListSet<ChatMessage>(){
        @Override
        public boolean add(ChatMessage o) {
            if(this.size() > 2048){
                threadPool.submit(new MessageArchiveService(new LinkedList<>(this)));
                clear();
            }
            return super.add(o);
        }
    });

    class WatchDog implements Runnable{

        @Override
        public void run() {
            while (serverThread.isAlive()){
                try {

                    Thread.sleep(5000);

                    if(!sessions.isEmpty()) {
                        ChatSession session = sessions.peek();
                        if (!session.isAlive()) {
                            session = sessions.take();
                            session.terminate();
                            Logger.log(WatchDog.class,"session was terminated");
                        }
                    }
                } catch (InterruptedException ignored) {}
            }
        }
    }


    public ChatServer(int port) throws IOException {
        socket = new ServerSocket(port);
        serverThread = new Thread(this);
        serverThread.setName("Server Thread");
        watchdogThread = new Thread(new WatchDog());
        watchdogThread.setName("Server Session WatchDog");
    }

    public static void main(String[] args) throws IOException {
    	if(args.length > 0){
    		verbose  = true;
    	}
    	
        ChatServer chatServer = new ChatServer(8080);
        chatServer.init();

    }

    public void init(){
        Logger.log(ChatServer.class,"Server Started");
        serverThread.start();
        watchdogThread.start();

    }

    @Override
    public void run() {
        messages.addListener(new ObservableSet.SetChangeListener<ChatMessage>() {
            @Override
            public void onChanged(ChatMessage change) {
                    for (ChatSession session : sessions) {
                        try {
                            session.sendto(change);
                        } catch (Exception e) {
                        }
                    }

            }
        });
        while (true){
            try {
                Socket incoming = socket.accept();
                Logger.log(ChatServer.class,"connection established with:"+incoming.getRemoteSocketAddress());
                
                catchConnection(incoming);
                
            } catch (IOException e) {
                Logger.log(ChatServer.class,"connection error",e);
                e.printStackTrace();
            }
        }
    }

	private void catchConnection(Socket incoming) {
		ChatSession session = new ChatSession(incoming);
		if(session.build(messages,sessions)) {
		    threadPool.submit(session.getMessageHandler());
		    threadPool.submit(session.getSendHandler());
		    sessions.add(session);
		}
	}

}
