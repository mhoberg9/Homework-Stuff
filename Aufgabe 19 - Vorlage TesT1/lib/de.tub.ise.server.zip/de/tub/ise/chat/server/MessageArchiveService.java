package de.tub.ise.chat.server;

import de.tub.ise.chat.ChatMessage;
import de.tub.ise.chat.util.Logger;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.LinkedList;
import java.util.stream.Collectors;

public class MessageArchiveService implements Runnable {
    final LinkedList<ChatMessage> chatMessages;
    public MessageArchiveService(LinkedList<ChatMessage> chatMessages) {
        this.chatMessages = chatMessages;
    }

    @Override
    public void run() {
        Path archiveFile = Paths.get("archive.txt");
        try(BufferedWriter bf = new BufferedWriter(new FileWriter(archiveFile.toFile(),true))) {
            for(String message:
            chatMessages.stream()
                    .map(ChatMessage::serialize)
                    .collect(Collectors.toList())){
                bf.write(message);
                bf.newLine();
            }
            bf.flush();
        } catch (IOException e) {}
        Logger.log(MessageArchiveService.class,String.format("%s %d",
                "archived messages",
                chatMessages.size()));
    }
}
