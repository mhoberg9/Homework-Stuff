package de.tub.ise.chat.server;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.Collections;
import java.util.LinkedList;
import java.util.Set;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.PriorityBlockingQueue;

import de.tub.ise.chat.ChatMessage;
import de.tub.ise.chat.util.Logger;

public class ChatSession implements Comparable<ChatSession> {

    private long lastHartBeat = System.currentTimeMillis()+WATCHDOG_TIMEOUT_IN_MS*2;

    static final int WATCHDOG_TIMEOUT_IN_MS = 30000;

    private final LinkedBlockingQueue<ChatMessage> sendQueue = new LinkedBlockingQueue<>();

    private final Socket socket;

    SendHandler sendHandler;
    IncomingMessageHandler messageHandler;
    private PriorityBlockingQueue<ChatSession> sessions;

	private Set<ChatMessage> messages;


    public SendHandler getSendHandler() {
        return sendHandler;
    }

    public IncomingMessageHandler getMessageHandler() {
        return messageHandler;
    }

    public ChatSession(Socket incoming) {
        this.socket = incoming;
    }

    public void sendto(ChatMessage elementAdded) {
        sendQueue.offer(elementAdded);
    }


    /**
     * creates a session object (factory pattern)
     * @param messages
     * @param sessions
     * @return
     */
    public boolean build(Set<ChatMessage> messages, PriorityBlockingQueue<ChatSession> sessions) {
        BufferedReader fromClient = null;
        PrintWriter toClient = null;
        try {
            toClient = new PrintWriter (new OutputStreamWriter(socket.getOutputStream()));
            fromClient = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            this.sessions = sessions;
            this.messages = messages;
            sendHandler = new SendHandler(this,sendQueue,toClient);
            messageHandler = new IncomingMessageHandler(this,
                    socket.getRemoteSocketAddress().toString(),
                    fromClient,
                    messages);
            return true;
        } catch (Exception e) {
            Logger.log(ChatSession.class,"failed to connect",e);
            if(toClient != null){
                toClient.write("Server ERROR\n");
                try{
                    toClient.close();
                } catch (Exception ignored){}
            }
        }
        return false;

    }

    @Override
    public int compareTo(ChatSession o) {
        return Long.compare(lastHartBeat,o.lastHartBeat);
    }

    /**
     * closes socket permanently
     * subsequent messages to this client or messeges form this clinet will be dropped
     */
    public void terminate() {
        Logger.log(ChatSession.class,"terminating connection lost");
        try {
            socket.close();
            lastHartBeat = 0;
        } catch (IOException e) {}
    }


    /**
     * resets the client timeout
     */
    public void reset(){
        sessions.remove(this);
        if(lastHartBeat != -1){
	        lastHartBeat = System.currentTimeMillis() + WATCHDOG_TIMEOUT_IN_MS;
	        sessions.offer(this);
        }
    }

    /**
     *
     * @return if the client is over the timeout
     */
    public boolean isAlive() {
        return lastHartBeat+WATCHDOG_TIMEOUT_IN_MS > System.currentTimeMillis();
    }

	public void quit() {
		lastHartBeat = -1;
	}

	public void sendHistory() {
		LinkedList<ChatMessage> messages = new LinkedList<>(this.messages);
		Collections.sort(messages);
		for(ChatMessage msg : messages.subList(0, Math.min(30,messages.size()))){
			sendto(msg);
		}
		messages.clear();
		messages = null;
	}


}
