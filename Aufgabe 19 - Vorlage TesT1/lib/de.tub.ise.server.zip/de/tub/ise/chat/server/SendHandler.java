package de.tub.ise.chat.server;

import de.tub.ise.chat.ChatMessage;
import de.tub.ise.chat.util.Logger;

import java.io.PrintWriter;
import java.util.concurrent.LinkedBlockingQueue;

/**
 * Created by Sebastian Werner on 30.01.2017.
 */
class SendHandler implements Runnable {
    private final LinkedBlockingQueue<ChatMessage> sendQueue;
    private final PrintWriter toClient;
    private final ChatSession session;

    SendHandler(ChatSession session,
                LinkedBlockingQueue<ChatMessage> sendQueue,
                PrintWriter toClient) {
        this.session = session;
        this.sendQueue = sendQueue;
        this.toClient = toClient;
    }


    @Override
    public void run() {
        while (session.isAlive()) {
            try {
                ChatMessage take = sendQueue.take();
                if(ChatServer.verbose){
                	Logger.log(getClass(),"sending...:"+take);
                }
                toClient.println(ChatMessage.serialize(take));
                toClient.flush();
            } catch (InterruptedException e) {
                Logger.log(SendHandler.class, "failed to send", e);
            }
        }
    }
}
