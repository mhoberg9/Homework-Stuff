package de.tub.ise.chat.server;

import java.util.Collection;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.Set;

/**
 * creates a set with a callback on the add method,
 * @see java listener pattern
 * @author Sebastian Werner
 *
 * @param <T>
 */
public class ObservableSetWrapper<T> implements ObservableSet<T> {

    private final Set<T> base;

    public ObservableSetWrapper(Set<T> collection) {
        base = collection;
    }

    LinkedList<SetChangeListener<T>> listeners = new LinkedList<>();

    @Override
    public void addListener(SetChangeListener<T> changeListener) {
        listeners.add(changeListener);
    }

    @Override
    public int size() {
        return base.size();
    }

    @Override
    public boolean isEmpty() {
        return base.isEmpty();
    }

    @Override
    public boolean contains(Object o) {
        return base.contains(o);
    }

    @Override
    public Iterator<T> iterator() {
        return base.iterator();
    }

    @Override
    public Object[] toArray() {
        return base.toArray();
    }

    @Override
    public <X> X[] toArray(X[] a) {
        return base.toArray(a);
    }

    @Override
    public boolean add(T message) {
        boolean success =  base.add(message);
        notify(message);
        return success;
    }

    private void notify(T message) {
        listeners.forEach(s->s.onChanged(message));
    }

    @Override
    public boolean remove(Object o) {
        return base.remove(o);
    }

    @Override
    public boolean containsAll(Collection<?> c) {
        return base.containsAll(c);
    }

    @Override
    public boolean addAll(Collection<? extends T> c) {
        return base.addAll(c);
    }

    @Override
    public boolean retainAll(Collection<?> c) {
        return base.retainAll(c);
    }

    @Override
    public boolean removeAll(Collection<?> c) {
        return base.removeAll(c);
    }

    @Override
    public void clear() {
        base.clear();
    }
}
