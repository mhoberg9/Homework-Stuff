package de.tub.ise.chat.server;

import de.tub.ise.chat.ChatMessage;
import de.tub.ise.chat.Commands;
import de.tub.ise.chat.util.Logger;

import java.io.BufferedReader;
import java.util.Calendar;
import java.util.Set;

class IncomingMessageHandler implements Runnable {
	private static final long RATE_LIMIT_MS = 250;
	private static final int OFFENCE_LIMIT = 15;
	
	private ChatSession chatSession;
	final BufferedReader fromClient;
	final Set<ChatMessage> messages;
	private final String clientIP;

	private long lastMessage = 0;
	private int offenceCounter = 0;

	IncomingMessageHandler(ChatSession chatSession, String clientIP, BufferedReader fromClient,
			Set<ChatMessage> messages) {
		this.chatSession = chatSession;
		this.clientIP = clientIP;
		this.messages = messages;
		this.fromClient = fromClient;
	}

	@Override
	public void run() {
		if (fromClient != null) {
			while (chatSession.isAlive()) {
				try {
					String line = fromClient.readLine();
					if (line == null)
						continue;

					if (checkIfWeAreOffendedYet())
						break;

					// stop message spam
					if (rateLimit())
						continue;

					lastMessage = System.currentTimeMillis();

					if (checkMessage(line))
						continue;

					processMessage(line);

					chatSession.reset();
				} catch (Exception e) {
					Logger.log(IncomingMessageHandler.class, "failed to read", e);
				}
			}
		}
	}
	
	private void processMessage(String line) {
		line = line.trim();
		if (!line.isEmpty()) {
			ChatMessage chatMessage = ChatMessage.deserialize(line);

			if (ChatServer.verbose) {
				Logger.log(getClass(), String.format("%s %s", "got messages", chatMessage));
			}

			chatMessage.setIP(clientIP);
			chatMessage.setTime(Calendar.getInstance());
			
			Commands command = getCommandFromMessage(chatMessage);
			
			processCommand(command);
			
			if (chatMessage.getBody() != null && !chatMessage.getBody().isEmpty()) {
				messages.add(chatMessage);
			}
		}
	}

	@SuppressWarnings("incomplete-switch")
	private void processCommand(Commands command) {
		switch (command) {
		case SEND_HISTORY:
			chatSession.sendHistory();
			Logger.log(IncomingMessageHandler.class, "sending history");
			break;
		case QUIT:
			chatSession.quit();
			Logger.log(IncomingMessageHandler.class, "recived quit");
			break;
		}
	}

	private Commands getCommandFromMessage(ChatMessage chatMessage) {
		Commands command = Commands.MESSAGE;
		if (chatMessage.getCommand() != null) {
			try {
				command = Commands.valueOf(chatMessage.getCommand());
			} catch (Exception ignored) {
			}
		}
		return command;
	}

	private boolean checkMessage(String line) {
		if (line.length() > 2000) {
			Logger.log(getClass(), "client send to long message!");
			chatSession.sendto(new ChatMessage("system", "Yo way to long message Boyo!"));
			chatSession.reset();
			offenceCounter++;
			return true;
		} else {
			return false;
		}
	}

	private boolean rateLimit() {
		if (!ChatServer.verbose && lastMessage + RATE_LIMIT_MS > System.currentTimeMillis()) {
			Logger.log(getClass(), "to many messages ratelimiting client!");
			chatSession.sendto(new ChatMessage("system", "Yo chill a little!"));
			chatSession.reset();
			try {
				Thread.sleep(RATE_LIMIT_MS);
			} catch (InterruptedException e) {
			}
			offenceCounter++;
			return true;
		}
		return false;
	}
	
	private boolean checkIfWeAreOffendedYet() {
		if (offenceCounter > OFFENCE_LIMIT) {
			Logger.log(IncomingMessageHandler.class, "killing connectiont to spammed messages ");
			chatSession.sendto(new ChatMessage("system", "to many Messages bro!"));
			chatSession.quit();
			return true;
		} else {
			return false;
		}
	}

}
