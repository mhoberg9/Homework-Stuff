package de.tub.ise.chat.server;

import java.util.Set;

/**
 * 
 * @author Sebastian Werner
 *
 * @param <T>
 */
public interface ObservableSet<T> extends Set<T> {
    void addListener(SetChangeListener<T> changeListener);


    public interface SetChangeListener<T>{
         void onChanged(T change);
    }
}
