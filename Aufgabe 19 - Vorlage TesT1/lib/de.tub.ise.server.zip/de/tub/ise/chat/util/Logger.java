package de.tub.ise.chat.util;

import java.text.SimpleDateFormat;
import java.util.Calendar;

public class Logger {
    static final SimpleDateFormat dateformat = new SimpleDateFormat("dd.MM.Y HH.mm");

    public static void log(Class<?> cally,String message){
        if(cally != null) {
            System.out.printf("[%s][%s] from:%s %n",
                    cally.getName(),
                    dateformat.format(Calendar.getInstance().getTime()),
                    message);
        } else {
            System.out.printf("[%s] from:%s %s %n",
                    dateformat.format(Calendar.getInstance().getTime()),
                    message);
        }
    }

    public static void log(String message){
        log(null,message);
    }

    public static void log(Class<?> cally, String message, Exception e) {
        log(cally,message);
        e.printStackTrace();
    }
}
