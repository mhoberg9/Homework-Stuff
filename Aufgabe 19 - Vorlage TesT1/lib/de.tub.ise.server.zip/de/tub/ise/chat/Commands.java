package de.tub.ise.chat;

public enum Commands {
	SEND_HISTORY,
	MESSAGE,
	QUIT;
}
