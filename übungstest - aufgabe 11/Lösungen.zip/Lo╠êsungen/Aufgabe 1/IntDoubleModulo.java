public class IntDoubleModulo
{
  public static void main(String [] args)
  {
    int i = 10/3;
    int j = 10%3;
    double d = 10/3.0;
    System.out.println("Double-Division: 10/3.0 = " + d);
    System.out.println("Integer-Division:  10/3 = " + i);
    System.out.println("Rest:              10%3 = " + j);
  }
}
